"""One-time script: reads a medical PDF, splits it into chunks, embeds them
and uploads them to your Pinecone index.

Usage:  python ingest.py data/Medical_book.pdf

Run it once per book. Running it again on the same index adds duplicate chunks.
"""
import os, sys
from dotenv import load_dotenv
from pinecone import Pinecone, ServerlessSpec
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_pinecone import PineconeVectorStore

load_dotenv()
INDEX_NAME = os.getenv("PINECONE_INDEX", "medical-chatbot")

if len(sys.argv) != 2 or not os.path.exists(sys.argv[1]):
    sys.exit("Usage: python ingest.py path/to/book.pdf")

pages = PyPDFLoader(sys.argv[1]).load()
chunks = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=20).split_documents(pages)
print(f"Loaded {len(pages)} pages, created {len(chunks)} chunks")

pc = Pinecone(api_key=os.environ["PINECONE_API_KEY"])
if INDEX_NAME not in pc.list_indexes().names():
    pc.create_index(name=INDEX_NAME, dimension=384, metric="cosine",
                    spec=ServerlessSpec(cloud="aws", region="us-east-1"))
    print("Created index", INDEX_NAME)

embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
PineconeVectorStore.from_documents(documents=chunks, index_name=INDEX_NAME, embedding=embeddings)
print("Done. Your book is now searchable.")
