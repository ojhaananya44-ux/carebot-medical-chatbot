import os, re, json, uuid, threading
from datetime import date, datetime, timedelta
from dotenv import load_dotenv
from flask import Flask, render_template, request, jsonify
from pypdf import PdfReader
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_pinecone import PineconeVectorStore
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

load_dotenv()  # reads GROQ_API_KEY and PINECONE_API_KEY from .env

INDEX_NAME = os.getenv("PINECONE_INDEX", "medical-chatbot")
APPT_FILE = "appointments.json"
lock = threading.Lock()

# ---------- RAG setup ----------
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
docsearch = PineconeVectorStore.from_existing_index(index_name=INDEX_NAME, embedding=embeddings)
retriever = docsearch.as_retriever(search_type="similarity", search_kwargs={"k": 3})
llm = ChatGroq(model="openai/gpt-oss-20b", temperature=0)


def rule(lang):
    if lang in ("", "auto"):
        return "Reply in the same language the user wrote in."
    return f"Reply in {lang}."


# The book is in English, so non-English questions are translated before retrieval.
translate = ChatPromptTemplate.from_messages([
    ("system", "Translate the user's text into English. Output only the translation. "
               "If it is already English, repeat it unchanged."),
    ("human", "{text}"),
]) | llm | StrOutputParser()

answer = ChatPromptTemplate.from_messages([
    ("system", "You are a medical question-answering assistant. Use the retrieved context to answer. "
               "If you don't know, say so. Use at most four short sentences. "
               "This is general educational information, not a substitute for professional medical advice. "
               "{rule}\n\nContext:\n{context}"),
    ("human", "{input}"),
]) | llm | StrOutputParser()

report_chain = ChatPromptTemplate.from_messages([
    ("system", "You explain medical test reports to patients in plain, calm language. "
               "From the report text, give: (1) a 2-3 sentence summary; (2) the key results as short bullet "
               "points starting with '- ', each with the value, the reference range if shown, and whether it is "
               "within, above or below range; (3) what any out-of-range items can generally mean, without "
               "diagnosing; (4) 3 questions to ask the doctor. Never diagnose or suggest medication. "
               "Use **bold** for section titles. End by saying a doctor should review the report. {rule}"),
    ("human", "Report text:\n{report}"),
]) | llm | StrOutputParser()

# ---------- Appointments (sample doctors: replace with your real list) ----------
SLOTS = ["09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "14:00", "14:30", "15:00", "15:30", "16:00"]
DOCTORS = [
    {"id": "d1", "name": "Dr. Ananya Sharma", "specialty": "General Physician", "slots": SLOTS},
    {"id": "d2", "name": "Dr. Rohan Mehta", "specialty": "Dermatologist", "slots": SLOTS},
    {"id": "d3", "name": "Dr. Priya Nair", "specialty": "Endocrinologist", "slots": SLOTS},
    {"id": "d4", "name": "Dr. Imran Qureshi", "specialty": "Cardiologist", "slots": SLOTS},
]


def load_appts():
    if not os.path.exists(APPT_FILE):
        return []
    with open(APPT_FILE) as f:
        return json.load(f)


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB uploads


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message, lang = data.get("message", "").strip(), data.get("language", "auto")
    if not message:
        return jsonify(error="Type a question first."), 400
    try:
        query = message if lang == "English" else translate.invoke({"text": message})
        docs = retriever.invoke(query)
        context = "\n\n".join(d.page_content for d in docs)
        text = answer.invoke({"context": context, "input": message, "rule": rule(lang)})
        pages = sorted({int(d.metadata["page"]) + 1 for d in docs if "page" in d.metadata})
        return jsonify(answer=text, pages=pages)
    except Exception:
        app.logger.exception("chat failed")
        return jsonify(error="Something went wrong on the server. Check the terminal for details."), 500


@app.route("/analyze", methods=["POST"])
def analyze():
    lang = request.form.get("language", "auto")
    text = request.form.get("text", "").strip()
    f = request.files.get("report")
    try:
        if f and f.filename:
            name = f.filename.lower()
            if name.endswith(".pdf"):
                text = "\n".join((p.extract_text() or "") for p in PdfReader(f.stream).pages)
            elif name.endswith(".txt"):
                text = f.read().decode("utf-8", errors="ignore")
            else:
                return jsonify(error="Upload a PDF or .txt file, or paste the report text."), 400
        text = text.strip()
        if len(text) < 30:
            return jsonify(error="No readable text found. For scanned reports, type or paste the values instead."), 400
        result = report_chain.invoke({"report": text[:12000], "rule": rule(lang)})
        return jsonify(analysis=result)
    except Exception:
        app.logger.exception("analyze failed")
        return jsonify(error="Could not analyse this report. Try a text-based PDF or paste the text."), 500


@app.route("/api/doctors")
def doctors():
    return jsonify(DOCTORS)


@app.route("/api/booked")
def booked():
    d, day = request.args.get("doctor"), request.args.get("date")
    taken = [a["time"] for a in load_appts() if a["doctor_id"] == d and a["date"] == day]
    return jsonify(taken)


@app.route("/api/appointments", methods=["POST"])
def book():
    b = request.get_json(silent=True) or {}
    doc = next((x for x in DOCTORS if x["id"] == b.get("doctor_id")), None)
    name, phone = b.get("name", "").strip(), re.sub(r"[\s-]", "", b.get("phone", ""))
    try:
        day = datetime.strptime(b.get("date", ""), "%Y-%m-%d").date()
    except ValueError:
        return jsonify(error="Choose a valid date."), 400
    if not doc:
        return jsonify(error="Choose a doctor."), 400
    if not (date.today() <= day <= date.today() + timedelta(days=60)):
        return jsonify(error="Choose a date within the next 60 days."), 400
    if b.get("time") not in doc["slots"]:
        return jsonify(error="Choose a time slot."), 400
    if len(name) < 2:
        return jsonify(error="Enter your full name."), 400
    if not re.fullmatch(r"\+?\d{8,15}", phone):
        return jsonify(error="Enter a valid phone number."), 400
    with lock:
        appts = load_appts()
        if any(a["doctor_id"] == doc["id"] and a["date"] == b["date"] and a["time"] == b["time"] for a in appts):
            return jsonify(error="That slot was just taken. Pick another time."), 409
        rec = {"id": uuid.uuid4().hex[:8].upper(), "doctor_id": doc["id"], "doctor": doc["name"],
               "specialty": doc["specialty"], "date": b["date"], "time": b["time"], "name": name,
               "phone": phone, "reason": b.get("reason", "").strip()[:300]}
        appts.append(rec)
        with open(APPT_FILE, "w") as f:
            json.dump(appts, f, indent=2)
    return jsonify(rec), 201


if __name__ == "__main__":
    app.run(debug=os.getenv("FLASK_DEBUG") == "1", port=int(os.getenv("PORT", 8080)))
