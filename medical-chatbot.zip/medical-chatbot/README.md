# CareBot – Medical Book Assistant

A web app that answers medical questions from a medical book you provide, using Retrieval-Augmented Generation (RAG). It also explains medical test reports in plain language and lets users book doctor appointments.

> **Disclaimer:** CareBot gives general educational information only. It is not a medical device and does not replace advice from a qualified doctor. In an emergency, call your local emergency number.

## Features

- **Ask questions** – answers are grounded in your book and show the page numbers they came from.
- **Any language** – choose from 12 languages or auto-detect. Questions in other languages are translated for search, and answers come back in the chosen language. The interface itself is translated for English and Hindi.
- **Report analysis** – upload a text-based PDF or paste lab results to get a plain-language summary, in-range / out-of-range values, and questions to ask your doctor. It never diagnoses.
- **Doctor appointments** – pick a doctor, date and free slot. Double-booking is blocked and bookings are saved to `appointments.json`.

## How it works

```
Browser (templates/index.html)
        │  fetch()
        ▼
Flask API (app.py)
  /chat      → translate query → Pinecone search → Groq LLM → answer + book pages
  /analyze   → read PDF/text → Groq LLM → plain-language summary
  /api/...   → doctors, free slots, bookings (appointments.json)
```

Stack: Flask, LangChain, Pinecone (vector database), Hugging Face `all-MiniLM-L6-v2` embeddings, Groq (`openai/gpt-oss-20b`), plain HTML/CSS/JS.

## Project structure

```
.
├── app.py              # Flask server and API routes
├── ingest.py           # One-time script: PDF → chunks → Pinecone
├── templates/
│   └── index.html      # The whole frontend
├── data/               # Put your book PDF here (not committed)
├── requirements.txt
├── Procfile            # For Render / Railway / Heroku
├── .env.example        # Template for your API keys
└── LICENSE
```

## Setup

You need Python 3.10+, a free [Groq](https://console.groq.com) API key and a free [Pinecone](https://www.pinecone.io) API key.

```bash
git clone https://github.com/<your-username>/<your-repo>.git
cd <your-repo>

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env            # then edit .env and add your keys
```

### 1. Index your book (once)

Copy your PDF into `data/` and run:

```bash
python ingest.py data/Medical_book.pdf
```

This creates the Pinecone index (named `medical-chatbot` by default) and uploads the book. Don't run it twice on the same index, or chunks will be duplicated.

### 2. Start the app

```bash
python app.py
```

Open http://localhost:8080. The first start is slow while the embedding model downloads.

## Configuration

| Variable | Purpose |
|---|---|
| `GROQ_API_KEY` | Groq API key |
| `PINECONE_API_KEY` | Pinecone API key |
| `PINECONE_INDEX` | Index name (default `medical-chatbot`) |
| `FLASK_DEBUG` | `1` for local development only |

## Customising

- **Doctors:** the `DOCTORS` list in `app.py` holds sample data. Replace it with your real doctors and time slots.
- **Languages:** add an `<option>` to the language dropdown in `templates/index.html`. To translate the interface too, add an entry to the `T` object.
- **Model:** change the model name in `app.py` where `ChatGroq` is created.

## Deploying (Render example)

1. Push this repo to GitHub.
2. On [Render](https://render.com), create a new **Web Service** from the repo.
3. Build command: `pip install -r requirements.txt`. Start command: `gunicorn app:app --timeout 120 --workers 1`.
4. Add `GROQ_API_KEY`, `PINECONE_API_KEY` and `PINECONE_INDEX` as environment variables.

The embedding model needs roughly 1 GB of memory, so a free tier instance may be too small. Also note that most hosts reset the disk on every deploy, so `appointments.json` will be lost. Use a real database for production.

## Security and privacy

- Never commit `.env`. It is already in `.gitignore`.
- `appointments.json` stores patient names and phone numbers and is git-ignored. For real patients, use a proper database and follow the health-data laws that apply to you.
- Uploaded report text is sent to Groq to generate the summary.
- There is no login or rate limiting. Add both before exposing the app publicly.

## Limitations

- Scanned reports and photos are not supported (no OCR). Users can paste the values instead.
- Answers are only as good as the book you index.
- Appointments have no email or SMS confirmation yet.

## License

MIT. See [LICENSE](LICENSE).
